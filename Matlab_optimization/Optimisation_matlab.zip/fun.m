function [ f ] = fun( x )
f = x(2); % renvoie simplement R, la grandeur à optimiser
          % dans ce problème
end